# DWG Forecast Intelligence — Web v0.1

Chromebook-first Delaware forecasting workstation.

## What works now
- Live NWS observations for Wilmington, Dover, Georgetown and Rehoboth Beach
- Active Delaware NWS alerts
- NWS point forecast guidance
- Four-zone Delaware command center
- Forecaster decision desk
- Model desk architecture for HRRR/RAP/GFS/GEFS/NBM
- Verification framework
- Graceful fallback/demo data if the NWS feed is unreachable

## Best way to use on a Chromebook
Deploy this repository to Streamlit Community Cloud. Once deployed, the workstation is just a web URL and requires no local Python installation.

### Deployment
1. Put these files in a GitHub repository.
2. Sign in to Streamlit Community Cloud.
3. Create a new app from the repository.
4. Set the main file to `streamlit_app.py`.
5. Deploy.
6. Bookmark the resulting URL on your Chromebook.

## Local Linux option
If Linux development environment is enabled on the Chromebook:

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
streamlit run streamlit_app.py
```

## v0.2 target
- Direct HRRR/RAP/GFS/GEFS point extraction
- Run-to-run trend engine
- Consensus ranges
- Ensemble spread
- Calculated confidence
- Persistent PostgreSQL/Supabase forecast archive

## Data note
Official NWS alerts remain clearly separate from DWG analysis. Automated guidance should not silently overwrite the forecaster's decision.
